import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  TextInput,
  ScrollView,
  
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const Educationapply = ({route}) => {
  const { Education_Id } = route.params;
  const navigation = useNavigation();
  
  const [isEditing, setIsEditing] = useState(true); // Start in editing mode
  

  
  // State variables to hold edited values
  const [editedName, setEditedName] = useState('');
  const [editedNickname, setEditedNickname] = useState('');
  const [editedAddress, setEditedAddress] = useState('');
  const [editedTelephonenumber, setEditedTelephonenumber] = useState('');
  


  const handleCancelPress = () => {
    // Navigate back to the board without saving changes
    setIsEditing(false);
    navigation.goBack();
  };

  const handleSavePress = () => {
    // Handle the logic to save the new content (e.g., send to the server)
    // For now, simply log the new content
    console.log('New Name:', editedName);
    console.log('New Nickname:', editedNickname);
    console.log('New Address:', editedAddress);
    console.log('New Telephonenumber:', editedTelephonenumber);
    
    // Navigate back to the board with the new content
    setIsEditing(false);
    navigation.goBack();
  };

  const renderContent = () => {
    return (
      <>
        <View style={styles.editableContent}>
          <Text style={styles.label}>신청자 이름</Text>
          <TextInput
            style={styles.input}
            placeholder="신청자 이름을 입력하세요."
            value={editedName}
            onChangeText={(text) => setEditedName(text)}
          />
        </View>
        <View style={styles.editableContent}>
          <Text style={styles.label}>닉네임</Text>
          <TextInput
            style={styles.input}
            multiline
            placeholder="닉네임을 입력하세요"
            value={editedNickname}
            onChangeText={(text) => setEditedNickname(text)}
          />
        </View>
        <View style={styles.editableContent}>
          <Text style={styles.label}>주소</Text>
          <TextInput
            style={styles.input}
            placeholder="주소를 입력하세요"
            value={editedAddress}
            onChangeText={(text) => setEditedAddress(text)}
          />
        </View>
        <View style={styles.editableContent}>
          <Text style={styles.label}>전화번호</Text>
          <TextInput
            style={styles.input}
            placeholder="전화번호를 입력하세요"
            value={editedTelephonenumber}
            onChangeText={(text) => setEditedTelephonenumber(text)}
          />
        </View>

       
        </>
    );
  };

  return (
    <ScrollView>
      <View  style={styles.container}>
        <View style={styles.boardTitle}>

          <TouchableOpacity style={styles.button} onPress={handleSavePress}>
            <Text style={styles.buttonText}>저장</Text>
          </TouchableOpacity>

          <View>
            <Text style={styles.titleText}>교육 게시판</Text>
            <Text style={styles.subtitleText}>교육 관련글 게시</Text>
          </View>

          <TouchableOpacity style={styles.button} onPress={handleCancelPress}>
            <Text style={styles.buttonText}>취소</Text>
          </TouchableOpacity>

        </View>

        
          <View style={styles.boardViewWrap}>
            <View style={styles.boardView}>{renderContent()}</View>
          </View>
      </View>
    </ScrollView>

  );
};


const styles = StyleSheet.create({
  container: {
    marginTop: StatusBar.currentHeight,
    backgroundColor: '#F0F0F0',
    padding: 30,
  },
  boardTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    margin: 20,
  },
  titleText: {
    fontSize: 24,
    paddingBottom: 10,
    fontWeight: 'bold',
  },
  subtitleText: {
    fontSize: 16,
    color: 'black',
  },
  button: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },

  boardViewWrap: {},

  boardView: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'black',
  },

  editableContent: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderColor: 'black',
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    paddingVertical: 5,
  },

   applyButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 8,
    marginTop: 10,
    marginBottom: 20,
    alignSelf: 'center',
    width: '70%',
  },
  applyButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
  },
});

export default Educationapply;
