//BoardJobDetail.js
//수정사항(1127) - 수정, 목록 버튼 디자인 통일 (자유게시판)
// 수정 버튼을 누를 때, 일반 네비게이션이 아닌, 게시글을 구성하는 매개변수의 데이터를 수정 컴포넌트로 넘길 수 있게 수정
// 백엔드와 연동이 되는 부분이여서, 엑스포만으로는 디버깅하기 어려운 부분이 있음
// Import necessary dependencies
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, StatusBar, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';


const Educationdetail3 = ({ route }) => {
  // Get the job details from the route params
  const { Education_Id } = route.params;




  const navigation = useNavigation();

  // Dummy data for job details (replace with actual data retrieval logic)
  const Educationdetail1 = {
    id: 1,
    title: '교육.',
    writer: '홍길동',
    date: '2021.1.16',
    count: 33,
    content: `
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
      글 내용이 들어갑니다
    `,
    EducationInfo: {
      companyName: '교육명',
      industry: '업종',
      businessType: '교육내용',
      establishmentDate: '2023.11.12',
      employeeCount: '00명',
      CEO: '강사명',
    },
  };

  const handleEditPress = () => {
    // Navigate to the edit screen (BoardJobEdit)
    navigation.navigate('Education_edit1', {
      screen: 'Education_edit1',
      params: { Education_Id },
    });
  };
  const handleListPress = () => {
    // Navigate to the list screen (Board_Job)
    
    
  };


  const handleApplyPress = () => {
    navigation.navigate('Educationapply', { 
        screen: 'Educationapply',
        params: { Education_Id },
      });
  };
  
  return (
    <ScrollView>
      <View style={styles.container}>

        <View style={styles.boardTitle}>
          
        <View style={styles.buttonWrap}>
          <TouchableOpacity style={styles.button} onPress={handleEditPress}>
            <Text style={styles.buttonText}>수정</Text>
          </TouchableOpacity>
        </View>
            
            <View>
              <Text style={styles.titleText}>교육 관련 게시판</Text>
              <Text style={styles.subtitleText}>구인 관련글 게시</Text>
            </View>
            
            <View style={styles.buttonWrap}>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Education_view2')}>
            <Text style={styles.buttonText}>목록</Text>
          </TouchableOpacity>
        </View>
        </View>
        
        <View style={styles.boardViewWrap}>
        
          <View style={styles.boardView}>
            
            <Text style={styles.title}>제목: {Educationdetail1.title}</Text>

            <View style={styles.info}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>번호</Text>
                <Text style={styles.infoValue}>{Educationdetail1.id}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>작성자</Text>
                <Text style={styles.infoValue}>{Educationdetail1.writer}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>작성일</Text>
                <Text style={styles.infoValue}>{Educationdetail1.date}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>조회</Text>
                <Text style={styles.infoValue}>{Educationdetail1.count}</Text>
              </View>
            </View>

            <Text style={styles.content}>{Educationdetail1.content}</Text>

            <Text style={styles.title}>교육정보</Text>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>교육명</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.EducationName}</Text>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>교육종류</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.industry}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>교육내용</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.EducationType}</Text>
              </View>
            
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>교육기간</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.establishmentDate}</Text>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>모집인원</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.EducationCount}</Text>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>강사이름</Text>
                <Text style={styles.infoValue}>{Educationdetail1.EducationInfo.CEO}</Text>
              </View>
            
          </View>
        </View>
        <View style={styles.applyButtonWrp}>
        <TouchableOpacity style={styles.applyButton} onPress={handleApplyPress}>
            <Text style={styles.applyButtonText}>신청하기</Text>
        </TouchableOpacity>
        </View>
      </View>
      
    </ScrollView>
    
  );
};


const styles = StyleSheet.create({
  container: {
    marginTop: StatusBar.currentHeight,
    backgroundColor: '#F0F0F0',
    paddingBottom: 30,
    paddingHorizontal: 20
  },
  boardTitle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    margin: 20,
    paddingTop: 20
  },

  titleText: {
    fontSize: 24,
    paddingBottom: 10,
    fontWeight: 'bold',
  },
  subtitleText: {
    fontSize: 16,
    color: 'black',
  },
  boardView: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'black',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  info: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderColor: 'black',
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderColor: 'gray',
    marginBottom: 5,
    paddingVertical: 5,
  },
  infoLabel: {
    fontWeight: 'bold',
  },
  infoValue: {
    marginLeft: 10,
  },
  content: {
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },

  applyButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 8,
    marginTop: 10,
    marginBottom: 20,
    alignSelf: 'center',
    width: '70%',
  },
  applyButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
  },
});

export default Educationdetail3;
